F2_jsonpCallback_com_openf2_examples_javascript_helloworld({
	"scripts":[
		"../apps/JavaScript/HelloWorld/appclass.js"
	],
	"styles":[],
	"apps":[
		{
			"html":[
				'<div>',
					'<div class="f2-app-view" data-f2-view="home">',
						'<p>Hello World! Test modals:</p>',
						'<a href="#" class="btn btn-default testAlert">Alert Modal</a>&nbsp;',
						'<a href="#" class="btn btn-default testConfirm">Confirm Modal</a>',
					'</div>',
				'</div>'
			].join("")
		}
	]
})