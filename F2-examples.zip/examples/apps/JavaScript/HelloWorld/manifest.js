F2_jsonpCallback_com_openf2_examples_javascript_helloworld({
	scripts: ['../apps/JavaScript/HelloWorld/appclass.js'],
	styles: [],
	apps: [
		{
			html: [
				'<div>',
				'<div>',
				'<p>Hello World! Test modals:</p>',
				'<a href="#" class="btn btn-default testAlert">Alert Modal</a>&nbsp;',
				'<a href="#" class="btn btn-default testConfirm">Confirm Modal</a>',
				'</div>',
				'</div>'
			].join('')
		}
	]
});
