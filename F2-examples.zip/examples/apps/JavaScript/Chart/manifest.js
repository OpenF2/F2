F2_jsonpCallback_com_openf2_examples_javascript_chart({
	"scripts":[
		"http://code.highcharts.com/highcharts.js",
		"../apps/JavaScript/Chart/appclass.js"
	],   
	"styles":[
		"../apps/JavaScript/Chart/app.css"
	],   
	"apps":[{
		"html":[
			'<div>',
				'<div id="f2-1year-chart-container">',
					'<div id="f2-1year-chart"></div>',
				'</div>',
			'</div>'
		].join("")
	}]
})