﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OpenF2.Examples.CSharp.Models
{
	public class AppContent
	{
		public object data { get; set; }
		public string html { get; set; }
	}
}