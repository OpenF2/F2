F2_jsonpCallback_com_openf2_examples_php_f2wits({
	"scripts":[
		"../apps/PHP/F2wits/moment.1.7.0.min.js",
		"../apps/PHP/F2wits/app.js"
	],	 
	"styles":[
		"../apps/PHP/F2wits/app.css"
	],	 
	"apps":[{
			"html":[
				'<div class="f2-app-view" data-f2-view="home"></div>',
				'<div class="f2-app-view hide" data-f2-view="about"><p>App version 1.0. Designed for F2 1.0</p></div>'
			].join("")
	}]
})