F2_jsonpCallback_com_openf2_examples_php_f2wits({
	"scripts":[
		"../apps/PHP/F2wits/moment.1.7.0.min.js",
		"../apps/PHP/F2wits/app.js"
	],	 
	"styles":[
		"../apps/PHP/F2wits/app.css"
	],	 
	"apps":[{
			"html":[
				'<div data-f2-view="home"></div>'
			].join("")
	}]
})